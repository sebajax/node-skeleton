/**
 * @description execute console job to compare local / session & cookies with old yapo with new yapo data
 * @param {function} newExperienceService
 * @param {function} blocketService
 * @param {function} blocketService
 * @param {function} printUtil
 * @param {object} logger
 * @return {object}
 */
export default async function sessionAnalizerConsole({
  newExperienceService,
  blocketService,
  newExperienceLogoutService,
  printUtil,
  logger,
}) {
  try {
    // execute new experience
    const newExperienceData = await newExperienceService(logger);
    // execute blocket
    const blocketData = await blocketService(logger);
    // execute logout in new experience
    const newExperienceLogoutData = await newExperienceLogoutService(logger);

    // compare and print reportinng between new experience & blocket
    printUtil(newExperienceData.data, blocketData.data);

    // compare and print reportinng between new experience & blocket
    printUtil(newExperienceLogoutData.data, newExperienceData.data);

    return true;
  } catch (error) {
    logger.error(error);
    return false;
  }
}
