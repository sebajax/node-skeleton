// module imports
import { v4 as uuidv4 } from 'uuid';
// console imports
import sessionAnalizerConsole from './sessionAnalizer.console';
// services import
import {
  newExperienceService,
  blocketService,
  newExperienceLogoutService,
} from '../services';
// utils import
import makeLogger from '../utils/logger.util';
import printUtil from '../utils/print.util';

// generate logger instance
const logger = makeLogger({ uuid: uuidv4(), url: 'sessionAnalizer.console' });

// check script exec
const args = process.argv.slice(2);

(async () => {
  switch (args[0]) {
    case 'sessionAnalizer':
      await sessionAnalizerConsole({
        newExperienceService,
        blocketService,
        newExperienceLogoutService,
        printUtil,
        logger,
      });
      break;
    default:
      logger.error('no script found for option');
  }
})();
