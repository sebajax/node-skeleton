// module imports
import { createClient } from 'redis';
// logger import
import logger from '../log/logger';

// default cache TTL
const defaultCacheTTL = parseInt(process.env.CACHE_DEFAULT_TTL, 10) || 3600;

/**
 * create connection to the cache
 */
const client = createClient({
  socket: {
    host: process.env.CACHE_HOST,
    port: parseInt(process.env.CACHE_PORT, 10) || 6379,
    reconnectStrategy: (retries) => {
      if (retries >= 0) {
        // end reconnecting with built in error
        return new Error('the server refused the connection');
      }
      return Math.min(retries * 50, 500);
    },
  },
});

/**
 * listen for connection events
 */
client.on('connect', () => logger.info('cache connection connect'));
client.on('ready', () => logger.info('cache connection ready'));
client.on('reconnecting', () => logger.info('cache connection reconnecting'));
client.on('error', () => logger.error('cache connection error'));
client.on('end', () => logger.info('cache connection end'));

(async () => {
  try {
    await client.connect();
  } catch (error) {
    logger.error(`the server refused the connection ${error}`);
  }
})();

/**
 * @return {Promise<boolean>}
 */
const ping = async () => {
  try {
    const checkConnection = await client.ping();
    if (checkConnection === 'PONG') return true;
  } catch (error) {
    logger.error(`the server refused the connection ${error}`);
  }

  // if not connected we try to re-establish connection to cache
  try {
    await client.connect();
    return false;
  } catch (error) {
    logger.error(`the server refused the connection ${error}`);
    return false;
  }
};

/**
 * @param {string} key
 * @return {Promise<string>}
 */
const getCache = async (key) => client.get(String(key));

/**
 * @param {string} key
 * @return {Promise<number>}
 */
const getCacheTTL = async (key) => client.ttl(String(key));

/**
 * @param {string} key
 * @param {string} data
 */
const setCache = async (key, data, cacheTTL) => {
  client.set(String(key), data);
  client.expire(String(key), cacheTTL || defaultCacheTTL);
};

/**
 * @param {string} key
 * @return {Promise<boolean>}
 */
const cacheExists = async (key) => client.exists(key);

/**
 * @param {string} key
 * @return {boolean}
 */
const delCache = (key) => client.del(key);

export default Object.freeze({
  ping,
  getCache,
  getCacheTTL,
  setCache,
  cacheExists,
  delCache,
});
