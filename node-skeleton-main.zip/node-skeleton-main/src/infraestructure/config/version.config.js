const VERSION_NUMBER = 'v1.0.0-lite';

const versionConfig = Object.freeze({
  VERSION_NUMBER,
});

export default versionConfig;
export { VERSION_NUMBER };
