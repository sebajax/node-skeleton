const EMAIL = process.env.YAPO_EMAIL;
const PASSWORD = process.env.YAPO_PASSWORD;

export default Object.freeze({
  EMAIL,
  PASSWORD,
});

export { EMAIL, PASSWORD };
