import statusCodes from 'http-status-codes';

/*
 * NOT_FOUND
 */

const CITY_NOT_FOUND = {
  error: true,
  message: 'CITY_NOT_FOUND',
  code: statusCodes.NOT_FOUND,
};

/*
 * BAD_REQUEST
 */

const IDENTITY_NUMBER_EXISTS = {
  error: true,
  message: 'IDENTITY_NUMBER_EXISTS',
  code: statusCodes.BAD_REQUEST,
};

/*
 * INTERNAL_SERVER_ERROR
 */

const NEW_CUSTOMER_SERVICE_ERROR = {
  error: true,
  message: 'NEW_CUSTOMER_SERVICE_ERROR',
  code: statusCodes.INTERNAL_SERVER_ERROR,
};

const NEW_CUSTOMER_SERVICE_DATABASE_ERROR = {
  error: true,
  message: 'NEW_CUSTOMER_SERVICE_DATABASE_ERROR',
  code: statusCodes.INTERNAL_SERVER_ERROR,
};

/*
 * CREATE
 */

const NEW_CUSTOMER_CREATED = {
  error: false,
  message: 'NEW_CUSTOMER_CREATED',
  code: statusCodes.CREATED,
};

export default Object.freeze({
  CITY_NOT_FOUND,
  IDENTITY_NUMBER_EXISTS,
  NEW_CUSTOMER_SERVICE_ERROR,
  NEW_CUSTOMER_SERVICE_DATABASE_ERROR,
  NEW_CUSTOMER_CREATED,
});

export {
  CITY_NOT_FOUND,
  IDENTITY_NUMBER_EXISTS,
  NEW_CUSTOMER_SERVICE_ERROR,
  NEW_CUSTOMER_SERVICE_DATABASE_ERROR,
  NEW_CUSTOMER_CREATED,
};
