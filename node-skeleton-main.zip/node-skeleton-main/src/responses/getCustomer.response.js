import statusCodes from 'http-status-codes';

/*
 * NOT_FOUND
 */

const GET_CUSTOMER_NOT_FOUND = {
  error: true,
  message: 'GET_CUSTOMER_NOT_FOUND',
  code: statusCodes.NOT_FOUND,
};

/*
 * INTERNAL_SERVER_ERROR
 */

const GET_CUSTOMER_ERROR = {
  error: true,
  message: 'GET_CUSTOMER_ERROR',
  code: statusCodes.INTERNAL_SERVER_ERROR,
};

/*
 * OK
 */

const OK = {
  error: false,
  message: 'OK',
  code: statusCodes.OK,
};

export default Object.freeze({
  GET_CUSTOMER_NOT_FOUND,
  GET_CUSTOMER_ERROR,
  OK,
});

export { GET_CUSTOMER_NOT_FOUND, GET_CUSTOMER_ERROR, OK };
