import statusCodes from 'http-status-codes';

/*
 * INTERNAL_SERVER_ERROR
 */

const GET_CUSTOMERS_ERROR = {
  error: true,
  message: 'GET_CUSTOMERS_ERROR',
  code: statusCodes.INTERNAL_SERVER_ERROR,
};

/*
 * OK
 */

const OK = {
  error: false,
  message: 'OK',
  code: statusCodes.OK,
};

export default Object.freeze({
  GET_CUSTOMERS_ERROR,
  OK,
});

export { GET_CUSTOMERS_ERROR, OK };
