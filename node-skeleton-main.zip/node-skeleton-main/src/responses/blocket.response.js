/*
 * INTERNAL_SERVER_ERROR
 */

const BLOCKET_SERVICE_ERROR = {
  error: true,
  message: 'BLOCKET_SERVICE_ERROR',
};

/*
 * OK
 */

const OK = {
  error: false,
  message: 'OK',
};

export default Object.freeze({
  BLOCKET_SERVICE_ERROR,
  OK,
});

export { BLOCKET_SERVICE_ERROR, OK };
