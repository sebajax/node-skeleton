import newExperienceResponse from './newExperience.response';
import blocketResponse from './blocket.response';
import newExperienceLogoutResponse from './newExperienceLogout.response';
import newCustomerResponse from './newCustomer.response';
import getCustomersResponse from './getCustomers.response';
import getCustomerResponse from './getCustomer.response';

export {
  newExperienceResponse,
  blocketResponse,
  newExperienceLogoutResponse,
  newCustomerResponse,
  getCustomersResponse,
  getCustomerResponse,
};
