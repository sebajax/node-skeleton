/*
 * INTERNAL_SERVER_ERROR
 */

const NEW_EXPERIENCE_LOGOUT_SERVICE_ERROR = {
  error: true,
  message: 'NEW_EXPERIENCE_LOGOUT_SERVICE_ERROR',
};

/*
 * OK
 */

const OK = {
  error: false,
  message: 'OK',
};

export default Object.freeze({
  NEW_EXPERIENCE_LOGOUT_SERVICE_ERROR,
  OK,
});

export { NEW_EXPERIENCE_LOGOUT_SERVICE_ERROR, OK };
