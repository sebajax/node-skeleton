// module imports
import Joi from 'joi';

/**
 * domain validation
 */
const newCustomerSchema = Joi.object({
  // required fields
  name: Joi.string().min(1).max(100).required(),
  identityNumber: Joi.string().min(1).max(45).required(),
  email: Joi.string().email({ minDomainSegments: 2 }).max(100).required(),
  phone: Joi.string().min(1).max(15).required(),
  address: Joi.string().min(3).required(),
  cityId: Joi.number().integer().strict().required().min(1),
});

const getCustomersSchema = Joi.object({
  page: Joi.number().integer().strict().required().min(1),
  // optional fields
  filter: Joi.object({
    active: Joi.boolean(),
  }),
  orderBy: Joi.object({
    name: Joi.string().required().valid('asc', 'desc'),
  }),
});

export { newCustomerSchema, getCustomersSchema };
