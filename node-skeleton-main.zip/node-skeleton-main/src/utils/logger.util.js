// module imports
import has from 'has';
import { StatusCodes, ReasonPhrases, getReasonPhrase } from 'http-status-codes';
// logger import
import logger from '../infraestructure/log/logger';

/**
 * @param {string} uuid
 * @param {string} url
 * @return {object}
 */
export default function makeLogger(uuid, url) {
  return {
    response: (code, message, data = undefined) => {
      switch (code) {
        case StatusCodes.OK || StatusCodes.CREATED:
          logger.info(`${url} RESPONSE`, {
            uuid,
            type: 'response',
            url,
            httpResponse: {
              code,
              message,
              data,
              status: getReasonPhrase(code),
            },
          });
          break;
        default:
          logger.warn(`${url} RESPONSE`, {
            uuid,
            type: 'response',
            url,
            httpResponse: {
              code,
              message,
              status: getReasonPhrase(code),
            },
          });
          break;
      }
    },
    error: (err) => {
      logger.error(`${url}`, {
        uuid,
        type: 'error',
        url,
        err: {
          message: err,
          stack: JSON.stringify(err.stack),
        },
      });
    },
    info: (logInfo) => {
      logger.info(`${url}`, {
        uuid,
        type: 'info',
        url,
        log_info: JSON.stringify(logInfo),
      });
    },
    unAuthorized: (err = null) => {
      const unAuthorizedLog = {
        uuid,
        type: 'response',
        url,
        httpResponse: {
          code: StatusCodes.UNAUTHORIZED,
          status: ReasonPhrases.UNAUTHORIZED,
        },
      };
      if (!err) {
        return logger.warn(`${url} RESPONSE`, unAuthorizedLog);
      }
      if (has(err, 'response')) {
        return logger.warn(`${url} RESPONSE`, unAuthorizedLog);
      }
      return logger.error(`${url} CHECK_TOKEN`, {
        uuid,
        type: 'middleware',
        url,
        err: {
          name: err.name,
          message: err.message,
          stack: JSON.stringify(err),
        },
      });
    },
    uuid,
  };
}
