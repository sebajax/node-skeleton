// module imports
import { differenceBy, difference, keys } from 'lodash';
import chalk from 'chalk';

const { log, table } = console;

/**
 * @description prints session reporting
 * @param {object} dataAnalyze
 * @param {object} dataCompare
 * @param {object} logger
 */
export default function printUtil(dataAnalyze, dataCompare) {
  // desctructuring all the data for better manipulation
  const {
    name: dataAnalyzeName,
    cookies: dataAnalyzeCookies,
    localStorage: dataAnalyzeLocalStorage,
    sessionStorage: dataAnalyzeSessionStorage,
  } = dataAnalyze;

  const {
    name: dataCompareName,
    cookies: dataCompareCookies,
    localStorage: dataCompareLocalStorage,
    sessionStorage: dataCompareSessionStorage,
  } = dataCompare;

  // cookies analyze
  log(
    chalk.bgBlue(
      chalk.bold(
        `### INI compare COOKIES between ${dataAnalyzeName} & ${dataCompareName} data ###`,
      ),
    ),
  );

  log(
    chalk.blue(
      `${dataAnalyzeName} cookies - ${dataAnalyzeCookies.length} ${dataCompareName} cookies - ${dataCompareCookies.length}`,
    ),
  );

  // check cookies
  const cookies = differenceBy(dataCompareCookies, dataAnalyzeCookies, 'name');

  log(chalk.blue(`missing ${cookies.length}`));

  const cookiesDiff = cookies.map((cookie) => {
    return cookie.name;
  });

  table(cookiesDiff);

  log(chalk.bgBlue(chalk.bold(`### END compare COOKIES ###`)));

  // local storage analyze
  log(
    chalk.bgCyan(
      chalk.bold(
        `### INI compare LOCAL STORAGE between ${dataAnalyzeName} & ${dataCompareName} data ###`,
      ),
    ),
  );

  log(
    chalk.cyan(
      `${dataAnalyzeName} local storage - ${
        keys(dataAnalyzeLocalStorage).length
      } ${dataCompareName} local storage - ${
        keys(dataCompareLocalStorage).length
      }`,
    ),
  );

  // check local
  const localKeysDataAnalyze = keys(dataAnalyzeLocalStorage);
  const localKeysDataCompare = keys(dataCompareLocalStorage);
  const localDiff = difference(localKeysDataCompare, localKeysDataAnalyze);

  log(chalk.cyan(`missing ${localDiff.length}`));
  table(localDiff);

  log(chalk.bgCyan(chalk.bold(`### END compare LOCAL STORAGE ###`)));

  // session storage analyze
  log(
    chalk.bgGreen(
      chalk.bold(
        `### INI compare SESSION STORAGE between ${dataAnalyzeName} & ${dataCompareName} data ###`,
      ),
    ),
  );

  log(
    chalk.green(
      `${dataAnalyzeName} session storage - ${
        keys(dataAnalyzeSessionStorage).length
      } ${dataCompareName} session storage - ${
        keys(dataCompareSessionStorage).length
      }`,
    ),
  );

  // check session
  const sessionKeysDataAnalyze = keys(dataAnalyzeSessionStorage);
  const sessionKeysDataCompare = keys(dataCompareSessionStorage);
  const sessionDiff = difference(
    sessionKeysDataCompare,
    sessionKeysDataAnalyze,
  );

  log(chalk.green(`missing ${sessionDiff.length}`));
  table(sessionDiff);

  log(chalk.bgGreen(chalk.bold(`### END compare SESSION STORAGE ###`)));
}
