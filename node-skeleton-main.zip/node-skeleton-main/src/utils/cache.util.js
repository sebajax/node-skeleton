import cacheClient from '../infraestructure/cache/client';

/**
 * @param {string} key
 * @param {object} logger
 * @return {object}
 */
const getCache = async (key, logger) => {
  try {
    const ping = await cacheClient.ping();
    if (!ping) return false;
    return {
      cacheData: JSON.parse(await cacheClient.getCache(key)),
      cacheTTL: await cacheClient.getCacheTTL(key),
    };
  } catch (error) {
    logger.info(`GET_CACHE_ERROR ${key}  ${error}`);
    return false;
  }
};

/**
 * @param {string} key
 * @param {object} data
 * @param {object} logger
 * @return {bool}
 */
const setCache = async (key, data, logger, cacheTTL = undefined) => {
  try {
    const ping = await cacheClient.ping();
    if (!ping) return false;
    cacheClient.setCache(key, JSON.stringify(data), cacheTTL);
    return true;
  } catch (error) {
    logger.info(`SET_CACHE_ERROR ${key}  ${error}`);
    return false;
  }
};

/**
 * @param {string} key
 * @param {object} logger
 * @returns {void}
 */
const delCache = async (key, logger) => {
  try {
    const ping = await cacheClient.ping();
    if (ping) {
      cacheClient.delCache(key);
    }
  } catch (error) {
    logger.info(`DEL_CACHE_ERROR ${key}  ${error}`);
  }
};

/**
 * @param {string} key
 * @return {bool}
 */
const cacheExists = async (key, logger) => {
  try {
    const ping = await cacheClient.ping();
    if (!ping) return false;
    return cacheClient.cacheExists(key);
  } catch (error) {
    logger.info(`CACHE_EXISTS_ERROR ${key}  ${error}`);
    return false;
  }
};

export default Object.freeze({
  getCache,
  setCache,
  delCache,
  cacheExists,
});
