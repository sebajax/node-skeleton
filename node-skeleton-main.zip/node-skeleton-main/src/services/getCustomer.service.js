/**
 * @param {object} customerModel
 * @param {object} cacheUtil
 * @param {object} getCustomerResponse
 * @return {function}
 */
export default function makeGetCustomerService(
  customerModel,
  cacheUtil,
  getCustomerResponse,
) {
  /**
   * @param {number} customerId
   * @param {object} getCustomerResponse
   * @param {object} logger
   * @return {object}
   */
  return async function getCustomerService(customerId, logger) {
    try {
      // get customer from cache
      const cacheKey = `GET_CUSTOMER_CACHE:${customerId}`;
      const { cacheData, cacheTTL } = await cacheUtil.getCache(
        cacheKey,
        logger,
      );

      // return customer from cache
      if (cacheData) {
        return {
          ...getCustomerResponse.OK,
          data: cacheData,
          headers: { cacheTTL },
        };
      }

      // get customer from db
      const customerData = await customerModel.getCustomer(customerId);
      if (!customerData) {
        return getCustomerResponse.GET_CUSTOMER_NOT_FOUND;
      }

      // set the info to cache
      cacheUtil.setCache(cacheKey, customerData, logger);

      // returns the project info
      return {
        ...getCustomerResponse.OK,
        data: customerData,
      };
    } catch (error) {
      logger.error(error);
      return getCustomerResponse.GET_CUSTOMER_ERROR;
    }
  };
}
