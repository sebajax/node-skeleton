/**
 * @param {object} customerModel
 * @param {object} cityModel
 * @param {object} newCustomerResponse
 * @returns {function}
 */
export default function makeNewCustomerService(
  customerModel,
  cityModel,
  newCustomerResponse,
) {
  /**
   * @param {object} customer
   * @param {object} logger
   * @returns {object}
   */
  return async function newCustomerService(customer, logger) {
    try {
      // validate city
      const checkCity = await cityModel.check(customer.cityId);
      if (!checkCity) {
        return newCustomerResponse.CITY_NOT_FOUND;
      }

      // validate city
      const checkIdentity = await customerModel.checkIdentity(
        customer.identityNumber,
      );
      if (checkIdentity) {
        return newCustomerResponse.IDENTITY_NUMBER_EXISTS;
      }

      // insert new customer in the database
      const createdCustomer = await customerModel.new(customer);
      if (!createdCustomer) {
        return newCustomerResponse.NEW_CUSTOMER_SERVICE_DATABASE_ERROR;
      }

      // the project was created successfully
      const { customerId } = createdCustomer;
      return {
        ...newCustomerResponse.NEW_CUSTOMER_CREATED,
        data: {
          customerId,
        },
      };
    } catch (error) {
      logger.error(error);
      return newCustomerResponse.NEW_CUSTOMER_SERVICE_ERROR;
    }
  };
}
