/**
 * @param {object} customerModel
 *  @param {object} paginationUtil
 * @param {object} getCustomerResponse
 * @returns {function}
 */
export default function makeGetCustomersService(
  customerModel,
  paginationUtil,
  getCustomerResponse,
) {
  /**
   * @param {object} filter
   * @param {number} page
   * @param {object} orderBy
   * @param {object} logger
   * @returns {object}
   */
  return async function getCustomersService(filter, page, orderBy, logger) {
    try {
      // transform orderBy object to a list of lists
      const order = Object.keys(orderBy).map((key) => [key, orderBy[key]]);

      // pagination data
      const { limit, offset } = paginationUtil.getPagination(page);

      // get all customers from db
      const customersDb = await customerModel.getCustomers(
        filter,
        order,
        limit,
        offset,
      );

      // get pagination info
      const { count, rows } = customersDb;
      const { totalPages, currentPage } = paginationUtil.getPagingData(
        count,
        page,
        limit,
      );

      return {
        ...getCustomerResponse.OK,
        data: {
          customers: rows,
          count,
          totalPages,
          currentPage,
        },
      };
    } catch (error) {
      logger.error(error);
      return getCustomerResponse.GET_CUSTOMERS_ERROR;
    }
  };
}
