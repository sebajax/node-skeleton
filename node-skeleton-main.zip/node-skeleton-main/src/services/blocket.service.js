/**
 * @param {{
 *    puppeteer: object,
 *    blocketResponse: object,
 *    environmentConfig: object,
 * }}
 * @return {function}
 */
export default function makeBlocketService(
  puppeteer,
  blocketResponse,
  environmentConfig,
) {
  /**
   * @param {object} logger
   * @return {object}
   */
  return async function blocketService(logger) {
    try {
      // open browser
      const browser = await puppeteer.launch({
        headless: false,
        args: ['--incognito'],
      });
      const page = await browser.newPage();
      await page.goto('https://www.yapo.cl/', {
        waitUntil: 'networkidle0',
      }); // wait until page load

      // login &  wait for navigation
      await page.click('#login-account-link');
      await page.keyboard.type(environmentConfig.EMAIL);
      await page.keyboard.press('Tab');
      await page.keyboard.type(environmentConfig.PASSWORD);
      await page.keyboard.press('Tab');
      await page.keyboard.press('Enter');
      await page.waitForNavigation({ waitUntil: 'networkidle0' });

      // get all the cookies
      const cookies = await page.cookies();

      // get all the localStorage
      const localStorage = await page.evaluate(() =>
        JSON.parse(JSON.stringify(localStorage)),
      );

      // get all the sessionStorage
      const sessionStorage = await page.evaluate(() =>
        JSON.parse(JSON.stringify(sessionStorage)),
      );

      // close browser
      await browser.close();

      return {
        ...blocketResponse.OK,
        data: {
          name: 'blocket',
          cookies,
          localStorage,
          sessionStorage,
        },
      };
    } catch (err) {
      logger.error(err);
      throw new Error(blocketResponse.BLOCKET_SERVICE_ERROR);
    }
  };
}
