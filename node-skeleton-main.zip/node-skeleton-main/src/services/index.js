// module imports
import puppeteer from 'puppeteer';
// service imports
import makeNewExperienceService from './newExperience.service';
import makeBlocketService from './blocket.service';
import makeNewExperienceLogoutService from './newExperienceLogout.service';
import makeNewCustomerService from './newCustomer.service';
import makeGetCustomersService from './getCustomers.service';
import makeGetCustomerService from './getCustomer.service';
// response imports
import {
  newExperienceResponse,
  blocketResponse,
  newExperienceLogoutResponse,
  newCustomerResponse,
  getCustomersResponse,
  getCustomerResponse,
} from '../responses';
// config imports
import environmentConfig from '../infraestructure/config/environment.config';
// model imports
import { customerModel, cityModel } from '../models';
// utils imports
import paginationUtil from '../utils/pagination.util';
import cacheUtil from '../utils/cache.util';

/* use case definitions */
const newExperienceService = makeNewExperienceService(
  puppeteer,
  newExperienceResponse,
  environmentConfig,
);
const blocketService = makeBlocketService(
  puppeteer,
  blocketResponse,
  environmentConfig,
);
const newExperienceLogoutService = makeNewExperienceLogoutService(
  puppeteer,
  newExperienceLogoutResponse,
  environmentConfig,
);
const newCustomerService = makeNewCustomerService(
  customerModel,
  cityModel,
  newCustomerResponse,
);
const getCustomersService = makeGetCustomersService(
  customerModel,
  paginationUtil,
  getCustomersResponse,
);
const getCustomerService = makeGetCustomerService(
  customerModel,
  cacheUtil,
  getCustomerResponse,
);

export {
  newExperienceService,
  blocketService,
  newExperienceLogoutService,
  newCustomerService,
  getCustomersService,
  getCustomerService,
};
