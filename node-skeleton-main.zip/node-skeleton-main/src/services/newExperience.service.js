/**
 * @param {{
 *    puppeteer: object,
 *    newExperienceResponse: object,
 *    environmentConfig: object,
 * }}
 * @return {function}
 */
export default function makeNewExperienceService(
  puppeteer,
  newExperienceResponse,
  environmentConfig,
) {
  /**
   * @param {object} logger
   * @return {object}
   */
  return async function newExperienceService(logger) {
    try {
      // open browser
      const browser = await puppeteer.launch({
        headless: false,
        args: ['--incognito'],
      });
      const page = await browser.newPage();
      await page.goto('https://new.yapo.cl/sellers/login/', {
        waitUntil: 'networkidle0',
      }); // wait until page load

      await page.type('#input-14', environmentConfig.EMAIL);
      await page.type('#input-15', environmentConfig.PASSWORD);

      // login &  wait for navigation
      await page.evaluate(`
        [...document.querySelectorAll('span')]
        .find((element) => element.textContent.trim() === 'Ingresar')
        .click();
      `);

      await page.waitForNavigation({ waitUntil: 'networkidle0' });

      await page.goto('https://new.yapo.cl/buyers/', {
        waitUntil: 'networkidle0',
      }); // wait until page load

      // get all the cookies
      const cookies = await page.cookies();

      // get all the localStorage
      const localStorage = await page.evaluate(() =>
        JSON.parse(JSON.stringify(localStorage)),
      );

      // get all the sessionStorage
      const sessionStorage = await page.evaluate(() =>
        JSON.parse(JSON.stringify(sessionStorage)),
      );

      // close browser
      await browser.close();

      return {
        ...newExperienceResponse.OK,
        data: {
          name: 'new experience',
          cookies,
          localStorage,
          sessionStorage,
        },
      };
    } catch (err) {
      logger.error(err);
      throw new Error(newExperienceResponse.NEW_EXPERIENCE_SERVICE_ERROR);
    }
  };
}
