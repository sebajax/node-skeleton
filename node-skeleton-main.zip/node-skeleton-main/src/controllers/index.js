// module imports
import has from 'has';
import statusCodes from 'http-status-codes';
// logger utils
import makeLogger from '../utils/logger.util';
// controller imports
import makeNewCustomerController from './newCustomer.controller';
import makeGetCustomersController from './getCustomers.controller';
import makeGetCustomerController from './getCustomer.controller';
// schema imports
import {
  newCustomerSchema,
  getCustomersSchema,
} from '../schemas/customer.schema';
// service imports
import {
  newCustomerService,
  getCustomersService,
  getCustomerService,
} from '../services';

/* handler definitions */
const newCustomerController = makeNewCustomerController(
  newCustomerService,
  newCustomerSchema,
  statusCodes,
  makeLogger,
);
const getCustomersController = makeGetCustomersController(
  getCustomersService,
  getCustomersSchema,
  statusCodes,
  makeLogger,
  has,
);
const getCustomerController = makeGetCustomerController(
  getCustomerService,
  statusCodes,
  makeLogger,
);

export { newCustomerController, getCustomersController, getCustomerController };
