/**
 * @param {function} getCustomerService
 * @param {object} statusCodes
 * @param {function} makeLogger
 * @return {function}
 */
export default function makeGetCustomerController(
  getCustomerService,
  statusCodes,
  makeLogger,
) {
  /**
   * @param {object} req
   * @param {object} res
   * @return {object}
   */
  return async function getCustomerController(req, res) {
    const { uuid, url } = req;
    const customerId = parseInt(req.params.customerId, 10);
    const logger = makeLogger({ uuid, url });

    try {
      // use case call
      const { error, message, code, data, headers } = await getCustomerService(
        customerId,
        logger,
      );
      logger.response(code, message, data);
      return res.status(code).set(headers).send({ error, message, data });
    } catch (err) {
      logger.error(`SERVER_ERROR ${err}`);
      return res
        .status(statusCodes.INTERNAL_SERVER_ERROR)
        .send({ error: true, message: 'SERVER_ERROR' });
    }
  };
}
