/**
 * @param {function} newCustomerService
 * @param {object} newCustomerSchema
 * @param {object} statusCodes
 * @param {function} makeLogger
 * @return {function}
 */
export default function makeNewCustomerController(
  newCustomerService,
  newCustomerSchema,
  statusCodes,
  makeLogger,
) {
  /**
   * @param {object} req
   * @param {object} res
   * @return {object}
   */
  return async function newCustomerController(req, res) {
    const { uuid, url } = req;
    const customer = req.body;
    const logger = makeLogger({ uuid, url });

    // request schema validation
    const { error: errorRequest } = newCustomerSchema.validate(customer);
    if (errorRequest) {
      logger.response(statusCodes.BAD_REQUEST, errorRequest.details[0].message);
      return res
        .status(statusCodes.BAD_REQUEST)
        .send({ error: true, message: errorRequest.details[0].message });
    }

    try {
      // use case call
      const { error, message, code, data } = await newCustomerService(
        customer,
        logger,
      );
      logger.response(code, message, data);
      return res.status(code).send({ error, message, data });
    } catch (err) {
      logger.error(`SERVER_ERROR ${err}`);
      return res
        .status(statusCodes.INTERNAL_SERVER_ERROR)
        .send({ error: true, message: 'SERVER_ERROR' });
    }
  };
}
