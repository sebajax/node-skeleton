// module imports
import sinon from 'sinon';

// fake the response with stub
const makeResMock = () => {
  const resMock = {};
  resMock.status = sinon.stub().returns(resMock);
  resMock.json = sinon.stub().returns(resMock);
  resMock.send = sinon.stub().returns(resMock);
  resMock.set = sinon.stub().returns(resMock);
  return resMock;
};

// fake makeLogeer with stub
const makeLoggerMock = () => {
  return sinon.stub().returns({
    info: sinon.stub(),
    error: sinon.stub(),
    response: sinon.stub(),
  });
};

// fake logger object with stub
const logger = {
  info: sinon.stub(),
  error: sinon.stub(),
  response: sinon.stub(),
  uuid: 'uuidfake',
};

// fake environment variables
const environmentConfig = {};

export { makeResMock, makeLoggerMock, logger, environmentConfig };
