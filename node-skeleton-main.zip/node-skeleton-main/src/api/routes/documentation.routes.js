// module imports
import express from 'express';
// swagger import
import swaggerUi from 'swagger-ui-express';
import swaggerJsDoc from 'swagger-jsdoc';
// version number import
import { VERSION_NUMBER } from '../../infraestructure/config/version.config';

const router = express.Router();

// Extended: https://swagger.io/specification/#infoObject
const swaggerOptions = {
  swaggerDefinition: {
    openapi: '3.0.0',
    info: {
      version: VERSION_NUMBER,
      title: 'Node Skeleton',
      description:
        'Yapo - Node lite skeleton for creating micro-services apis with 3 layer architecture.',
      contact: {
        name: '$_POST[team]',
      },
      servers: [
        {
          url: 'http://localhost:5000',
          description: 'Dev Server',
        },
      ],
    },
  },
  // Paths to files containing OpenAPI definitions
  apis: ['./src/api/routes/*.js'],
};

const swaggerDocs = swaggerJsDoc(swaggerOptions);
router.use('/docs', swaggerUi.serve, swaggerUi.setup(swaggerDocs));

export default router;
