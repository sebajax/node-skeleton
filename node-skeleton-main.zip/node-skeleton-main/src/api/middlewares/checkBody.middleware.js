// module imports
import { StatusCodes, ReasonPhrases } from 'http-status-codes';
// logger utils
import makeLogger from '../../utils/logger.util';

export default (req, res, next) => {
  if (Object.keys(req.body).length > 0) {
    return next();
  }
  const { uuid, url } = req;
  const logger = makeLogger({ uuid, url });
  logger.response(StatusCodes.BAD_REQUEST, ReasonPhrases.BAD_REQUEST);
  return res
    .status(StatusCodes.BAD_REQUEST)
    .send({ error: true, data: ReasonPhrases.BAD_REQUEST });
};
