// module imports
import has from 'has';
// model imports
import cityModel from './city.model';
import customerModel from './customer.model';

const Models = Object.freeze({
  cityModel,
  customerModel,
});

/*
  ##################
  #  Associations  #
  ##################
*/
Object.values(Models).forEach((Model) => {
  // create model associations
  if (has(Model, 'associate')) {
    Model.associate(Models);
  }
});

export { cityModel, customerModel };
