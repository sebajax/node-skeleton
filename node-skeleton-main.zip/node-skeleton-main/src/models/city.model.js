/* database configuration - import */
import db from '../infraestructure/database/db';

/* model - definition */
const cityModel = db.sequelize.define(
  'city',
  {
    cityId: {
      field: 'city_id',
      type: db.DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: db.DataTypes.STRING(100),
      allowNull: false,
      notEmpty: true,
    },
  },
  {
    timestamps: true,
    underscored: true,
    freezeTableName: true,
  },
);

/* model - associations */
cityModel.associate = (Models) => {
  cityModel.hasMany(Models.customerModel, {
    foreignKey: 'cityId',
  });
};

/* model - functions */
/**
 * @param {number} cityId
 * @return {object}
 */
cityModel.check = (cityId) => {
  return cityModel.findByPk(cityId);
};

export default cityModel;
