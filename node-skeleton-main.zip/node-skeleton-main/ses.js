// module imports
const puppeteer = require('puppeteer');
const { differenceBy, difference, keys } = require('lodash');

const email = 'caromorao@yahoo.es';
const password = 'maite1983';

const newExperience = async () => {
  // open browser
  const browser = await puppeteer.launch({
    headless: false,
    args: ['--incognito'],
  });
  const page = await browser.newPage();
  await page.goto('https://new.yapo.cl/sellers/login/', {
    waitUntil: 'networkidle0',
  }); // wait until page load

  await page.type('#input-14', email);
  await page.type('#input-15', password);

  // login &  wait for navigation
  await Promise.all([
    page.evaluate(() => {
      [...document.querySelectorAll('span')]
        .find((element) => element.textContent.trim() === 'Ingresar')
        .click();
    }),
    page.waitForNavigation({ waitUntil: 'networkidle0' }),
  ]);

  await page.goto('https://new.yapo.cl/buyers/', {
    waitUntil: 'networkidle0',
  }); // wait until page load

  // get all the cookies
  const newExperienceCookies = await page.cookies();

  // get all the localStorage
  const newExperienceLocal = await page.evaluate(() =>
    JSON.parse(JSON.stringify(localStorage)),
  );

  // get all the sessionStorage
  const newExperienceSession = await page.evaluate(() =>
    JSON.parse(JSON.stringify(sessionStorage)),
  );

  // close browser
  await browser.close();

  return {
    newExperienceCookies,
    newExperienceLocal,
    newExperienceSession,
  };
};

const blocket = async () => {
  // open browser
  const browser = await puppeteer.launch({
    headless: false,
    args: ['--incognito'],
  });
  const page = await browser.newPage();
  await page.goto('https://www.yapo.cl/', {
    waitUntil: 'networkidle0',
  }); // wait until page load

  // login &  wait for navigation
  await page.click('#login-account-link');
  await page.keyboard.type(email);
  await page.keyboard.press('Tab');
  await page.keyboard.type(password);
  await page.keyboard.press('Tab');
  await page.keyboard.press('Enter');
  await page.waitForNavigation({ waitUntil: 'networkidle0' });

  // get all the cookies
  const blocketCookies = await page.cookies();

  // get all the localStorage
  const blocketLocal = await page.evaluate(() =>
    JSON.parse(JSON.stringify(localStorage)),
  );

  // get all the sessionStorage
  const blocketSession = await page.evaluate(() =>
    JSON.parse(JSON.stringify(sessionStorage)),
  );

  // close browser
  await browser.close();

  return {
    blocketCookies,
    blocketLocal,
    blocketSession,
  };
};

const newExperienceLogout = async () => {
  // open browser
  const browser = await puppeteer.launch({
    headless: false,
    args: ['--incognito'],
  });
  const page = await browser.newPage();
  await page.goto('https://new.yapo.cl/sellers/login/', {
    waitUntil: 'networkidle0',
  }); // wait until page load

  await page.type('#input-14', email);
  await page.type('#input-15', password);

  // login &  wait for navigation
  await Promise.all([
    page.evaluate(() => {
      [...document.querySelectorAll('span')]
        .find((element) => element.textContent.trim() === 'Ingresar')
        .click();
    }),
    page.waitForNavigation({ waitUntil: 'networkidle0' }),
  ]);

  await page.goto('https://new.yapo.cl/buyers/', {
    waitUntil: 'networkidle0',
  }); // wait until page load

  await page.click('app-menu-header-md');

  await Promise.all([
    page.evaluate(() => {
      [...document.querySelectorAll('p')]
        .find((element) => element.textContent.trim() === 'Cerrar sesión')
        .click();
    }),
    page.waitForNavigation({ waitUntil: 'networkidle0' }),
  ]);

  // get all the cookies
  const newExperienceLogoutCookies = await page.cookies();

  // get all the localStorage
  const newExperienceLogoutLocal = await page.evaluate(() =>
    JSON.parse(JSON.stringify(localStorage)),
  );

  // get all the sessionStorage
  const newExperienceLogoutSession = await page.evaluate(() =>
    JSON.parse(JSON.stringify(sessionStorage)),
  );

  // close browser
  await browser.close();

  return {
    newExperienceLogoutCookies,
    newExperienceLogoutLocal,
    newExperienceLogoutSession,
  };
};

const printNewExperienceDiff = (newExperienceData, blocketData) => {
  // desctructuring all the data for better manipulation
  const {
    newExperienceCookies,
    newExperienceLocal,
    newExperienceSession,
  } = newExperienceData;

  const { blocketCookies, blocketLocal, blocketSession } = blocketData;

  console.log(
    '### INI compare local / session & cookies with old yapo with new yapo data ###',
  );

  console.log(
    `COOKIES data for new & old experience / new experience ${newExperienceCookies.length} / old experience ${blocketCookies.length} `,
  );

  console.log(
    `LOCAL STORAGE data for new & old experience / new experience: ${
      keys(newExperienceLocal).length
    } / old experience ${keys(blocketLocal).length} `,
  );

  console.log(
    `SESSION STORAGE data for new & old experience / new experience: ${
      keys(newExperienceSession).length
    } / old experience ${keys(blocketSession).length} `,
  );

  // check cookies
  const cookiesDiff = differenceBy(
    blocketCookies,
    newExperienceCookies,
    'name',
  );

  console.log(
    `COOKIES DIFFERENCE new experience missing ${cookiesDiff.length}`,
  );
  console.log(cookiesDiff);

  // check local
  const localKeysNE = keys(newExperienceLocal);
  const localKeysBlocket = keys(blocketLocal);
  const localDiff = difference(localKeysBlocket, localKeysNE);

  console.log(
    `LOCAL STORAGE DIFFERENCE new experience missing ${localDiff.length}`,
  );
  console.log(localDiff);

  // check session
  const sessionKeysNE = keys(newExperienceSession);
  const sessionKeysBlocket = keys(blocketSession);
  const sessionDiff = difference(sessionKeysBlocket, sessionKeysNE);

  console.log(`SESSION STORAGE new experience missing ${sessionDiff.length}`);
  console.log(sessionDiff);

  console.log(
    '### END compare local / session & cookies with old yapo with new yapo data ###',
  );
};

const printLogoutDiff = (newExperienceData, newExperienceLogoutData) => {
  // desctructuring all the data for better manipulation
  const {
    newExperienceCookies,
    newExperienceLocal,
    newExperienceSession,
  } = newExperienceData;

  const {
    newExperienceLogoutCookies,
    newExperienceLogoutLocal,
    newExperienceLogoutSession,
  } = newExperienceLogoutData;

  console.log(
    '### INI logout & check if local / session & cookies are being removed in new experience ###',
  );

  console.log(
    `COOKIES data logged new experience ${newExperienceCookies.length} / logged out new experience ${newExperienceLogoutCookies.length} `,
  );

  console.log(
    `LOCAL STORAGE data logged new experience ${
      keys(newExperienceLocal).length
    } / logged out new experience ${keys(newExperienceLogoutLocal).length} `,
  );

  console.log(
    `SESSION STORAGE data logged new experience ${
      keys(newExperienceSession).length
    } / logged out new experience ${keys(newExperienceLogoutSession).length} `,
  );

  console.log(
    '### END logout & check if local / session & cookies are being removed in new experience ###',
  );

  /**
   * compare local / session & cookies with logged new experience & logged out new experience
   */
  console.log(
    '### INI compare local / session & cookies with logged new experience & logged out new experience ###',
  );

  // check cookies
  const cookiesDiffLogout = differenceBy(
    newExperienceCookies,
    newExperienceLogoutCookies,
    'name',
  );

  console.log(
    `COOKIES REMOVED in looged out new experience ${cookiesDiffLogout.length}`,
  );
  console.log(cookiesDiffLogout);

  // check local
  const localKeysNE = keys(newExperienceLocal);
  const localKeysNELogout = keys(newExperienceLogoutLocal);
  const localDiffLogout = difference(localKeysNE, localKeysNELogout);

  console.log(
    `LOCAL STORAGE REMOVED in looged out new experience ${localDiffLogout.length}`,
  );
  console.log(localDiffLogout);

  // check session
  const sessionKeysNE = keys(newExperienceSession);
  const sessionKeysNELogout = keys(newExperienceLogoutSession);
  const sessionDiffLogout = difference(sessionKeysNE, sessionKeysNELogout);

  console.log(
    `SESSION STORAGE REMOVED in looged out new experience ${sessionDiffLogout.length}`,
  );
  console.log(sessionDiffLogout);

  console.log(
    '### END compare local / session & cookies with logged new experience & logged out new experience ###',
  );
};

// execute console job to compare local / session & cookies with old yapo with new yapo data
(async () => {
  // execute new experience
  const newExperienceData = await newExperience();
  // execute blocket
  const blocketData = await blocket();
  // execute logout in new experience
  const newExperienceLogoutData = await newExperienceLogout();

  /**
   * compare local / session & cookies with old yapo with new yapo data
   */
  printNewExperienceDiff(newExperienceData, blocketData);

  /**
   * logout & check if local / session & cookies are being removed in new experience
   */
  printLogoutDiff(newExperienceData, newExperienceLogoutData);
})();
