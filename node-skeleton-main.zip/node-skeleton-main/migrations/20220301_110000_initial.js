// module imports
import { DataTypes } from 'sequelize';

async function up({ context: queryInterface }) {
  /*
  --- independent tables ---
  these ones should be created first
  */
  await queryInterface.createTable('city', {
    cityId: {
      field: 'city_id',
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
      notEmpty: true,
    },
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE,
    },
  });

  /*
  --- dependent tables ---
  these ones should be created after the independent tables
  */

  // dependes on city
  await queryInterface.createTable('customer', {
    customerId: {
      field: 'customer_id',
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
      notEmpty: true,
    },
    identityNumber: {
      field: 'identity_number',
      type: DataTypes.STRING(45),
      allowNull: false,
      notEmpty: true,
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: false,
      notEmpty: true,
    },
    phone: {
      type: DataTypes.STRING(15),
      allowNull: false,
      notEmpty: true,
    },
    address: {
      type: DataTypes.TEXT,
      allowNull: false,
      notEmpty: true,
    },
    active: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE,
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE,
    },
    city_id: {
      field: 'city_id',
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'city',
        key: 'city_id',
      },
    },
  });

  /*
  --- add constraints to tables ---
  */

  /*
  --- add indexes to tables ---
  */
  await queryInterface.addIndex('customer', ['identity_number'], {
    name: 'idx_customer_identity_number',
  });

  /*
  --- seed tables ---
  */

  await queryInterface.bulkInsert('city', [
    {
      city_id: 1,
      name: 'Arica',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 2,
      name: 'Camarones',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 3,
      name: 'General Lagos',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 4,
      name: 'Putre',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 5,
      name: 'Alto Hospicio',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 6,
      name: 'Camiña',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 7,
      name: 'Colchane',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 8,
      name: 'Huara',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 9,
      name: 'Iquique',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 10,
      name: 'Pica',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 11,
      name: 'Pozo Almonte',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 12,
      name: 'Antofagasta',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 13,
      name: 'Calama',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 14,
      name: 'María Elena',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 15,
      name: 'Mejillones',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 16,
      name: 'Ollagüe',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 17,
      name: 'San Pedro de Atacama',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 18,
      name: 'Sierra Gorda',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 19,
      name: 'Taltal',
      created_at: new Date(),
      updated_at: new Date(),
    },
    {
      city_id: 20,
      name: 'Tocopilla',
      created_at: new Date(),
      updated_at: new Date(),
    },
  ]);
}

async function down({ context: queryInterface }) {
  /*
  --- remove constraints to tables ---
  */

  /*
  --- remove indexes to tables ---
  */
  await queryInterface.removeIndex('customer', 'idx_customer_identity_number');
  /*
  --- remove tables ---
  */
  await queryInterface.dropTable('city');
  await queryInterface.dropTable('customer');
}

export { up, down };
